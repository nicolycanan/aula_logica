#include <stdio.h>

int main()
{

    int numero,multiplicador, result;

    printf("digite um numero: ");
    scanf("%d", &numero);


    for (multiplicador=1; multiplicador <= 10; multiplicador++)
    {
        result=numero*multiplicador;
        printf("%d X %d = %d \n", numero, multiplicador, result);
    }

}
