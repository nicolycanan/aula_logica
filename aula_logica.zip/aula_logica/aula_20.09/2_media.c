#include <stdio.h>

int main()
{

    float n1,n2, m;

    //nota 1
    printf("Digite a primeira nota: ");
    scanf("%f", &n1);

    //nota 2
    printf("Digite a segunda nota: ");
    scanf("%f", &n2);

    //media
    m = (n1+n2)/2;
    printf("Sua media e: %.2f \n", m);

    printf("\n");

    //reprovada
    if(m <= 3.9)
    {
        printf("Reprovado.");
    }

    //exame
    if( m >= 4.0 && m <= 6.9 )
    {
        printf("Exame.");

    }

    //aprovado
    if( m >= 7)
    {
        printf("Aprovado.");

    }



}
