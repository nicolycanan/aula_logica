#include <stdio.h>

int main()
{

    float s, impostoR, sf;

    printf("Infomre o salario: ");
    scanf("%f", &s);

    if(s < 2259.20)
    {
        sf=s;
    }
    else
    {
        if(s <= 2826.65)
        {
            sf = (s * 0.075) - 169.44;
        }
        else
        {
            if(s<=3751.05)
            {
                sf= s-(s*0.15) + 381.44;

            }
            else
            {
                if(s<=4664.68)
                {
                    sf= s-(s*0.225)+662.77;
                }
                else
                {
                    sf= s-(s*0.225)+896.00;
                }
            }

        }

    }
                        printf("o salario final e: %.2f", sf);

}

