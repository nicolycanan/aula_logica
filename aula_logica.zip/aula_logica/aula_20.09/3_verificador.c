#include <stdio.h>

int main (){

    int n1, n2;

    //informe o n1
    printf("Informe o numero 1: ");
    scanf("%d", &n1);

    //informe o n2
    printf("Informe o numero 2: ");
    scanf("%d", &n2);

    printf("\n");

    //verificador
    //numeros diferentes
    if(n1 != n2){
        printf("Numeros diferentes.\n");
    } else {
        //numeros iguais
        printf("Numeros iguais.\n");
    }

    //qual e maior
    if(n1 < n2){
        printf("%d e maior", n1);
    }
    if(n1 > n2) {
        printf("%d e menor", n1);

    } else if(n1 = n2){
        printf("Os numeros sao iguals, nao tem maior.\n");

    }


}
