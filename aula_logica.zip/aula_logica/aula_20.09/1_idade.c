#include <stdio.h>

int main (){

    int aA, aN, id;

    printf("Digite o ano atual: ");
    scanf("%d", &aA);

    printf("Digite o ano de nascimento: ");
    scanf("%d", &aN);

    id = aA-aN;

    if(id >= 18){
        printf("Sua idade e: %d \n", id);
        printf("Maior de idade" );

    } else {
         printf("Sua idade e: %d \n", id);
        printf("Menor de idade");
    }

}

