#include <stdio.h>

int main()
{
    float real, cotacao, dolar, euro;
    int op;

    //opcoes
    printf("1 - Dolar para Real\n");
    printf("2 - Real para Dolar\n");
    printf("3 - Euro para Real\n");
    printf("4 - Real para Euro\n\n");

    //escolha uma opcao
    printf("Escolha uma opcao: ");
    scanf("%d", &op);

    //valor da cotacao
    printf("Informe a cotacao: ");
    scanf("%f", &cotacao);

    //1 - Dolar para Real
    if(op == 1)
    {
        printf("Quantidade em Dolar: ");
        scanf("%f", &dolar);

        real = dolar*cotacao;
        printf("O valor em Real e: %.2f", real);
    }

    //2 - Real para Dolar
    if(op == 2)
    {
        printf("Quantidade em Real: ");
        scanf("%f", &real);

        dolar = real*cotacao;
        printf("O valor em Dolar e: %.2f", dolar);
    }


    //3 - Euro para Real
    if(op == 3)
    {
        printf("Quantidade em Euro: ");
        scanf("%f", &euro);

        real = euro*cotacao;
        printf("O valor em Real e: %.2f", real);
    }

    //4 - Real para Euro
    if(op == 4)
    {
        printf("Quantidade em Real: ");
        scanf("%f", &real);

        euro = real*cotacao;
        printf("O valor em Euro e: %.2f", euro);
    }


    return 0;

}
